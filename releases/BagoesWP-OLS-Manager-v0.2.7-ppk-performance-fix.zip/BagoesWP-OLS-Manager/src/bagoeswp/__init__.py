"""BagoesWP OLS Manager."""

__version__ = "0.2.7"
